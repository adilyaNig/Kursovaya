﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kurs.Pages
{
    /// <summary>
    /// Логика взаимодействия для SamR.xaml
    /// </summary>
    public partial class SamR : Page
    {
        public SamR()
        {
            InitializeComponent();
        }

        private void Button_Click_Back(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Menu());
        }

        private void Button_Click_SamR1(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр страницы с Lab1Page
            SamR1 samR1 = new SamR1();

            // Загружаем HTML-файл
            samR1.LoadHtmlFile();

            // Открываем новую страницу
            NavigationService.Navigate(samR1);
        }
        private void Button_Click_SamR2(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр страницы с Lab1Page
            SamR2 samR2 = new SamR2();

            // Загружаем HTML-файл
            samR2.LoadHtmlFile();

            // Открываем новую страницу
            NavigationService.Navigate(samR2);
        }

        private void Button_Click_SamR3(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр страницы с Lab1Page
            SamR3 samR3 = new SamR3();

            // Загружаем HTML-файл
            samR3.LoadHtmlFile();

            // Открываем новую страницу
            NavigationService.Navigate(samR3);
        }

        private void Button_Click_SamR4(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр страницы с Lab1Page
            SamR4 samR4 = new SamR4();

            // Загружаем HTML-файл
            samR4.LoadHtmlFile();

            // Открываем новую страницу
            NavigationService.Navigate(samR4);
        }

    }
}
