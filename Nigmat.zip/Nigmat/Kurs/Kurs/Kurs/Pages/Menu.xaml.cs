﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kurs.Pages
{
    /// <summary>
    /// Логика взаимодействия для Menu.xaml
    /// </summary>
    public partial class Menu : Page
    {
        public Menu()
        {
            InitializeComponent();
        }
        
        private void Button_Click_Labs(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Labs());
        }


        private void Button_Click_SamR(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new SamR());
        }

        private void Button_Click_Spravka(object sender, RoutedEventArgs e)
        {
                Spravka spravka = new Spravka();
                spravka.LoadHtmlFile();
                NavigationService.Navigate(spravka);

        }

        private void Button_Click_Exit(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
